/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_177()
{
    return 2428995912U;
}

unsigned getval_139()
{
    return 1485772218U;
}

unsigned getval_371()
{
    return 3284633928U;
}

unsigned getval_246()
{
    return 3281031256U;
}

unsigned getval_454()
{
    return 2420684179U;
}

unsigned addval_162(unsigned x)
{
    return x + 3284633864U;
}

unsigned getval_306()
{
    return 3251079496U;
}

unsigned addval_124(unsigned x)
{
    return x + 3281293400U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_171(unsigned x)
{
    return x + 3221804683U;
}

void setval_221(unsigned *p)
{
    *p = 3381971593U;
}

unsigned getval_416()
{
    return 3286272072U;
}

unsigned getval_400()
{
    return 3281046025U;
}

void setval_250(unsigned *p)
{
    *p = 2430634344U;
}

void setval_381(unsigned *p)
{
    *p = 3677929929U;
}

unsigned addval_464(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_404(unsigned x)
{
    return x + 3525367433U;
}

unsigned getval_477()
{
    return 3221799305U;
}

unsigned addval_262(unsigned x)
{
    return x + 3676359177U;
}

unsigned getval_499()
{
    return 3281049227U;
}

void setval_201(unsigned *p)
{
    *p = 3372794248U;
}

unsigned addval_430(unsigned x)
{
    return x + 3526940169U;
}

unsigned addval_155(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_361(unsigned x)
{
    return x + 3348158089U;
}

unsigned getval_427()
{
    return 3677929869U;
}

unsigned getval_344()
{
    return 3232022921U;
}

unsigned getval_462()
{
    return 3281305993U;
}

unsigned getval_157()
{
    return 3372799657U;
}

unsigned addval_487(unsigned x)
{
    return x + 3677405577U;
}

unsigned addval_258(unsigned x)
{
    return x + 3767091383U;
}

unsigned getval_498()
{
    return 3529561737U;
}

void setval_307(unsigned *p)
{
    *p = 2430634312U;
}

unsigned addval_349(unsigned x)
{
    return x + 3767097344U;
}

unsigned addval_473(unsigned x)
{
    return x + 3683961481U;
}

unsigned getval_242()
{
    return 3252717896U;
}

unsigned getval_189()
{
    return 3281177225U;
}

unsigned addval_392(unsigned x)
{
    return x + 3281046153U;
}

unsigned addval_448(unsigned x)
{
    return x + 3526934921U;
}

unsigned addval_324(unsigned x)
{
    return x + 3676359305U;
}

unsigned addval_140(unsigned x)
{
    return x + 2425408153U;
}

void setval_123(unsigned *p)
{
    *p = 3531921033U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
